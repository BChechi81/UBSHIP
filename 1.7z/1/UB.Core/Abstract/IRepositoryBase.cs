﻿using System.Linq.Expressions;

namespace UB.Core.Abstract
{
    public interface IRepositoryBase<T>
    {
        IEnumerable<T> FindAll();
        IEnumerable<T> FindByCondition(Expression<Func<T, bool>> expression);
        Task<IEnumerable<T>> FindAllAsync();
        Task<IEnumerable<T>> FindByConditionAsync(Expression<Func<T, bool>> expression);
        Task<T> GetByIdAsync(int Id);
        Task<bool> GetAnyAsync(Expression<Func<T, bool>> predicate);
        Task<T> GetByFirstorDefaultAsync(Expression<Func<T, bool>> predicate);
        bool GetAny(Expression<Func<T, bool>> predicate);
        T GetByFirstorDefault(Expression<Func<T, bool>> predicate);
        T GetById(int Id);
        void Create(T entity);
        void Update(T entity);
        void Delete(T entity);
        void CreateRange(List<T> entitylist);
        void UpdateRange(List<T> entitylist);
        void Save();
        T GetById(Guid Id);
        void RemoveRange(List<T> entitylist);
    }
}
