﻿using Ub.Entity;

namespace UB.Core.Abstract
{
    public interface IShipingDetails : IRepositoryBase<ShippingDetail>
    {

    }
}
