﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace UB.Entities;

public partial class TestContext : DbContext
{
    public TestContext()
    {
    }

    public TestContext(DbContextOptions<TestContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Customer> Customers { get; set; }

    public virtual DbSet<District> Districts { get; set; }

    public virtual DbSet<Order> Orders { get; set; }

    public virtual DbSet<Product> Products { get; set; }

    public virtual DbSet<ShippingDetail> ShippingDetails { get; set; }

    public virtual DbSet<State> States { get; set; }

    public virtual DbSet<Tracking> Trackings { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
//#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=LAPTOP-ABHH2M6D;Initial Catalog=test;Persist Security Info=True;User ID=sa;Password=sa123456789#;Encrypt=True;TrustServerCertificate=True;ConnectRetryCount=0;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Customer>(entity =>
        {
            entity.HasKey(e => e.CustomerId).HasName("PK_tblCustomer");

            entity.ToTable("Customer");

            entity.Property(e => e.CustomerId).HasColumnName("CustomerID");
            entity.Property(e => e.Address1).HasMaxLength(50);
            entity.Property(e => e.Address2).HasMaxLength(50);
            entity.Property(e => e.ContactNo).HasMaxLength(10);
            entity.Property(e => e.CreatedOn).HasColumnType("datetime");
            entity.Property(e => e.CustomerName).HasMaxLength(100);
        });

        modelBuilder.Entity<District>(entity =>
        {
            entity.ToTable("District");

            entity.Property(e => e.DistrictName).HasMaxLength(50);
            entity.Property(e => e.StateId)
                .HasMaxLength(10)
                .IsFixedLength();
        });

        modelBuilder.Entity<Order>(entity =>
        {
            entity.HasKey(e => e.OrderId).HasName("PK_tblOrder");

            entity.ToTable("Order");

            entity.Property(e => e.OrderId)
                .ValueGeneratedNever()
                .HasColumnName("OrderID");
            entity.Property(e => e.CreatedOn).HasColumnType("datetime");
            entity.Property(e => e.OrderDate).HasColumnType("date");
            entity.Property(e => e.ProductId).HasColumnName("ProductID");
        });

        modelBuilder.Entity<Product>(entity =>
        {
            entity.HasKey(e => e.ProductId).HasName("PK_tblProduct");

            entity.ToTable("Product");

            entity.Property(e => e.ProductId).ValueGeneratedNever();
            entity.Property(e => e.ProductName).HasMaxLength(50);
            entity.Property(e => e.ProductPrice).HasColumnType("decimal(7, 2)");
        });

        modelBuilder.Entity<ShippingDetail>(entity =>
        {
            entity.HasKey(e => e.ShipingId).HasName("PK_ShippingDetails_1");

            entity.Property(e => e.ShipingId).HasColumnName("ShipingID");
            entity.Property(e => e.CreatedOn).HasColumnType("datetime");
            entity.Property(e => e.DeliveredOn).HasColumnType("datetime");
            entity.Property(e => e.DestDistrictId).HasColumnName("Dest_District_ID");
            entity.Property(e => e.DestPincode)
                .HasColumnType("numeric(6, 0)")
                .HasColumnName("Dest_pincode");
            entity.Property(e => e.DestStateId).HasColumnName("Dest_StateId");
            entity.Property(e => e.OriginDistrictId).HasColumnName("origin_DistrictId");
            entity.Property(e => e.OriginPincode)
                .HasColumnType("numeric(6, 0)")
                .HasColumnName("origin_pincode");
            entity.Property(e => e.OriginStateId).HasColumnName("origin_StateID");
            entity.Property(e => e.ShipingDestAddress)
                .HasMaxLength(50)
                .HasColumnName("Shiping_Dest_Address");
            entity.Property(e => e.ShipingDestAddress2)
                .HasMaxLength(100)
                .HasColumnName("Shiping_Dest_Address2");
            entity.Property(e => e.ShipingDestination)
                .HasMaxLength(50)
                .HasColumnName("Shiping_Destination");
            entity.Property(e => e.ShipingOrigin)
                .HasMaxLength(50)
                .HasColumnName("Shiping_Origin");
            entity.Property(e => e.ShipingRefNo).HasMaxLength(50);
            entity.Property(e => e.ShipingStatus)
                .HasMaxLength(50)
                .HasColumnName("shipingStatus");
            entity.Property(e => e.ShippingBy).HasColumnName("shippingBy");
            entity.Property(e => e.ShippingOriginAddress)
                .HasMaxLength(50)
                .HasColumnName("Shipping_origin_Address");
            entity.Property(e => e.ShippingOriginAddress2)
                .HasMaxLength(100)
                .HasColumnName("Shipping_origin_Address2");

            entity.HasOne(d => d.Customer).WithMany(p => p.ShippingDetails)
                .HasForeignKey(d => d.CustomerId)
                .HasConstraintName("FK_ShippingDetails_Customer1");

            entity.HasOne(d => d.DestDistrict).WithMany(p => p.ShippingDetailDestDistricts)
                .HasForeignKey(d => d.DestDistrictId)
                .HasConstraintName("FK_ShippingDetails_District1");

            entity.HasOne(d => d.DestState).WithMany(p => p.ShippingDetails)
                .HasForeignKey(d => d.DestStateId)
                .HasConstraintName("FK_ShippingDetails_State");

            entity.HasOne(d => d.OriginDistrict).WithMany(p => p.ShippingDetailOriginDistricts)
                .HasForeignKey(d => d.OriginDistrictId)
                .HasConstraintName("FK_ShippingDetails_District");
        });

        modelBuilder.Entity<State>(entity =>
        {
            entity.HasKey(e => e.StateId).HasName("PK_tblState");

            entity.ToTable("State");

            entity.Property(e => e.StateId)
                .ValueGeneratedNever()
                .HasColumnName("StateID");
            entity.Property(e => e.StateName).HasMaxLength(50);
        });

        modelBuilder.Entity<Tracking>(entity =>
        {
            entity.HasKey(e => e.TrackingId).HasName("PK_tblTracking");

            entity.ToTable("Tracking");

            entity.Property(e => e.TrackingId)
                .ValueGeneratedNever()
                .HasColumnName("TrackingID");
            entity.Property(e => e.CreatedOn).HasColumnType("datetime");
            entity.Property(e => e.CurrentStatus)
                .HasMaxLength(50)
                .HasColumnName("currentStatus");
            entity.Property(e => e.DeliveredDate).HasColumnType("datetime");
            entity.Property(e => e.PickupDate)
                .HasColumnType("datetime")
                .HasColumnName("pickupDate");
            entity.Property(e => e.ShipmentId).HasColumnName("ShipmentID");

            entity.HasOne(d => d.Shipment).WithMany(p => p.Trackings)
                .HasForeignKey(d => d.ShipmentId)
                .HasConstraintName("FK_Tracking_ShippingDetails");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
