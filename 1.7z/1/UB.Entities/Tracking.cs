﻿using System;
using System.Collections.Generic;

namespace UB.Entities;

public partial class Tracking
{
    public int TrackingId { get; set; }

    public int? ShipmentId { get; set; }

    public DateTime? PickupDate { get; set; }

    public string? CurrentStatus { get; set; }

    public DateTime? DeliveredDate { get; set; }

    public DateTime? CreatedOn { get; set; }

    public virtual ShippingDetail? Shipment { get; set; }
}
