﻿using System;
using System.Collections.Generic;

namespace UB.Entities;

public partial class Customer
{
    public int CustomerId { get; set; }

    public string? CustomerName { get; set; }

    public string? Address1 { get; set; }

    public string? Address2 { get; set; }

    public string? ContactNo { get; set; }

    public DateTime? CreatedOn { get; set; }

    public virtual ICollection<ShippingDetail> ShippingDetails { get; set; } = new List<ShippingDetail>();
}
