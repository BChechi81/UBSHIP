﻿using System;
using System.Collections.Generic;

namespace UB.Entities;

public partial class District
{
    public string StateId { get; set; } = null!;

    public int DistrictId { get; set; }

    public string? DistrictName { get; set; }

    public virtual ICollection<ShippingDetail> ShippingDetailDestDistricts { get; set; } = new List<ShippingDetail>();

    public virtual ICollection<ShippingDetail> ShippingDetailOriginDistricts { get; set; } = new List<ShippingDetail>();
}
