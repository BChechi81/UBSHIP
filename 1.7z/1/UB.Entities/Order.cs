﻿using System;
using System.Collections.Generic;

namespace UB.Entities;

public partial class Order
{
    public int OrderId { get; set; }

    public int? ProductId { get; set; }

    public int? CustomerId { get; set; }

    public DateTime? OrderDate { get; set; }

    public DateTime? CreatedOn { get; set; }
}
