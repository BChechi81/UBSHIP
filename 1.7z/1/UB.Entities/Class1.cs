﻿namespace UB.Entities
{
    public class Class1
    {

    }
}