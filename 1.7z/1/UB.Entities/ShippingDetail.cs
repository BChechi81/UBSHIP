﻿using System;
using System.Collections.Generic;

namespace UB.Entities;

public partial class ShippingDetail
{
    public int ShipingId { get; set; }

    public string? ShipingRefNo { get; set; }

    public int? CustomerId { get; set; }

    public string? ShipingOrigin { get; set; }

    public string? ShippingOriginAddress { get; set; }

    public string? ShippingOriginAddress2 { get; set; }

    public int? OriginStateId { get; set; }

    public int? OriginDistrictId { get; set; }

    public decimal? OriginPincode { get; set; }

    public string? ShipingDestination { get; set; }

    public string? ShipingDestAddress { get; set; }

    public string? ShipingDestAddress2 { get; set; }

    public int? DestStateId { get; set; }

    public int? DestDistrictId { get; set; }

    public decimal? DestPincode { get; set; }

    public int? ShippingBy { get; set; }

    public string? ShipingStatus { get; set; }

    public DateTime? CreatedOn { get; set; }

    public DateTime? DeliveredOn { get; set; }

    public virtual Customer? Customer { get; set; }

    public virtual District? DestDistrict { get; set; }

    public virtual State? DestState { get; set; }

    public virtual District? OriginDistrict { get; set; }

    public virtual ICollection<Tracking> Trackings { get; set; } = new List<Tracking>();
    
}
